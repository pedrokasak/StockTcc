#
# TABLE STRUCTURE FOR: billers
#

DROP TABLE IF EXISTS billers;

CREATE TABLE `billers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `invoice_footer` varchar(1000) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO billers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `logo`, `invoice_footer`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (2, 'Pedro Henrique', 'PHDEVELOPER', 'Rua F Ac Rua 96', 'Saquarema', 'RJ', '28990000', 'Brasil', '2298993874', 'pedrohesm@gmail.com', 'logo250.png', '&lt;p&gt;\r\n   COBRADOR.\r\n&lt;/p&gt;', '', '', '', '', '', '');
INSERT INTO billers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `logo`, `invoice_footer`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (5, 'Jefferson Aurore', 'Stand UP Comedy', 'Rua São José', 'Niterói', 'RJ', '24130350', 'Brasil', '2122240660', 'jefaurore@standup.com', 'logo.png', '', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: calendar
#

DROP TABLE IF EXISTS calendar;

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `data` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO categories (`id`, `code`, `name`) VALUES (5, 'IPS', 'IMPRESSORAS');
INSERT INTO categories (`id`, `code`, `name`) VALUES (2, 'CP', 'COMPUTADORES');
INSERT INTO categories (`id`, `code`, `name`) VALUES (3, 'TBT', 'TABLETS');
INSERT INTO categories (`id`, `code`, `name`) VALUES (4, 'SP', 'SMARTPHONES');


#
# TABLE STRUCTURE FOR: comment
#

DROP TABLE IF EXISTS comment;

CREATE TABLE `comment` (
  `comment` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO comment (`comment`) VALUES ('&lt;p&gt;\r\n &lt;strong&gt;&lt;/strong&gt;\r\n&lt;/p&gt;');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (4, 'Jefferson Aurore', 'Stand UP Comedy', 'Rua São José', 'Niterói', 'RJ', '24130350', 'Brasil', '2122240660', 'jefaurore@standup.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (2, 'Pedro Henrique', 'PHDEVELOPER', 'Rua F Ac Rua 96', 'Saquarema', 'Rio de Janeiro', '28990000', 'Brasil', '21969631823', 'pedrohesm@gmail.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (3, 'Leonardo Ferro', 'LF Consultoria', 'Rua do Tiroteio', 'Niterói', 'RJ', '24130350', 'Brasil', '2198765431', 'leoferro@example.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (5, 'Karolyne Correia', 'Suporte Técnico', 'Rua do Posto de Gasolina', 'São Gonçalo', 'Rio de Janeiro', '26547860', 'Brasil', '2122232434', 'karolyne.correa@homepack.com.br', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: damage_products
#

DROP TABLE IF EXISTS damage_products;

CREATE TABLE `damage_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO damage_products (`id`, `date`, `product_id`, `quantity`, `warehouse_id`, `note`, `user`, `updated_by`) VALUES (1, '2016-04-10', 2, 5, 2, '', 'Pedro Henrique Santanna', NULL);
INSERT INTO damage_products (`id`, `date`, `product_id`, `quantity`, `warehouse_id`, `note`, `user`, `updated_by`) VALUES (2, '2016-04-10', 2, 2, 3, '', 'Pedro Henrique Santanna', NULL);


#
# TABLE STRUCTURE FOR: date_format
#

DROP TABLE IF EXISTS date_format;

CREATE TABLE `date_format` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `js` varchar(20) NOT NULL,
  `php` varchar(20) NOT NULL,
  `sql` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (1, 'mm-dd-yyyy', 'm-d-Y', '%m-%d-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (2, 'mm/dd/yyyy', 'm/d/Y', '%m/%d/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (3, 'mm.dd.yyyy', 'm.d.Y', '%m.%d.%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (4, 'dd-mm-yyyy', 'd-m-Y', '%d-%m-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (5, 'dd/mm/yyyy', 'd/m/Y', '%d/%m/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (6, 'dd.mm.yyyy', 'd.m.Y', '%d.%m.%Y');


#
# TABLE STRUCTURE FOR: deliveries
#

DROP TABLE IF EXISTS deliveries;

CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `reference_no` varchar(55) NOT NULL,
  `customer` varchar(55) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: discounts
#

DROP TABLE IF EXISTS discounts;

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `discount` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (1, 'No Discount', '0.00', '2');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (2, '2.5 Percent', '2.50', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (3, '5 Percent', '5.00', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (4, '10 Percent', '10.00', '1');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS groups;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO groups (`id`, `name`, `description`) VALUES (1, 'owner', 'Owner');
INSERT INTO groups (`id`, `name`, `description`) VALUES (2, 'admin', 'Administrator');
INSERT INTO groups (`id`, `name`, `description`) VALUES (3, 'purchaser', 'Purchasing Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (4, 'salesman', 'Sales Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (5, 'viewer', 'View Only User');


#
# TABLE STRUCTURE FOR: invoice_types
#

DROP TABLE IF EXISTS invoice_types;

CREATE TABLE `invoice_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `type` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: pos_settings
#

DROP TABLE IF EXISTS pos_settings;

CREATE TABLE `pos_settings` (
  `pos_id` int(1) NOT NULL,
  `cat_limit` int(11) NOT NULL,
  `pro_limit` int(11) NOT NULL,
  `default_category` int(11) NOT NULL,
  `default_customer` int(11) NOT NULL,
  `default_biller` int(11) NOT NULL,
  `display_time` varchar(3) NOT NULL DEFAULT 'yes',
  `cf_title1` varchar(255) DEFAULT NULL,
  `cf_title2` varchar(255) DEFAULT NULL,
  `cf_value1` varchar(255) DEFAULT NULL,
  `cf_value2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pos_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO pos_settings (`pos_id`, `cat_limit`, `pro_limit`, `default_category`, `default_customer`, `default_biller`, `display_time`, `cf_title1`, `cf_title2`, `cf_value1`, `cf_value2`) VALUES (1, 22, 30, 4, 1, 1, 'yes', '', '', '', '');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` char(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `size` varchar(55) NOT NULL,
  `cost` decimal(25,2) DEFAULT NULL,
  `price` decimal(25,2) NOT NULL,
  `alert_quantity` int(11) NOT NULL DEFAULT '20',
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `cf1` varchar(255) DEFAULT NULL,
  `cf2` varchar(255) DEFAULT NULL,
  `cf3` varchar(255) DEFAULT NULL,
  `cf4` varchar(255) DEFAULT NULL,
  `cf5` varchar(255) DEFAULT NULL,
  `cf6` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `track_quantity` tinyint(4) DEFAULT '1',
  `details` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `category_id` (`category_id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`),
  KEY `category_id_2` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (1, 'SGT08', 'SAMSUNG GALAXY TAB 8\" 16 GB 3G WIFI', 'TABLET', '8 POLEGADAS', '500.00', '900.00', 2, 'no_image.jpg', 3, 3, '', '', '', '', '', '', 530, 2, 0, '<p>\r\n  <span >SAMSUNG GALAXY TAB 8\" 16 GB 3G WIFI CINZA</span>\r\n</p>');
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (4, 'QB', 'QBEX Windows 10 Quad Core 8 GB 500 GB', 'Desktop', '15 Polegadas', '800.00', '1650.00', 0, 'no_image.jpg', 2, 4, '', '', '', '', '', '', 140, 1, 1, '<p>\r\n Computador ALL IN ONE com Windows 10 super rápido bonito e eficiente.\r\n</p>');
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (3, 'NTP', 'ULTRABOOK POSITIVO 14\" TB 32 GB', 'NOTEBOOKS', '14 POLEGADAS', '800.00', '1600.00', 0, 'no_image.jpg', 2, 5, '', '', '', '', '', '', 510, 2, 0, '<p>\r\n   ULTRA BOOK DA POSITIVO PRA QUEM ACHA QUE TIRA ONDA COM POSITIVO\r\n</p>');
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (5, 'MMX', 'MOTO MAXX', 'Smartphone', '5,2 POLEGADAS', '600.00', '2200.00', 0, 'mtomaxx.jpg', 4, 2, '', '', '', '', '', '', 400, 1, 1, '<p>\r\n    Máxima performance sem limites O Moto Maxx foi criado para quem escolhe o próprio ritmo, oferecendo o máximo de potência e desempenho. Longa duração, carregamento rápido Fique até 40 horas longe da tomada Passe até 40 horas sem precisar recarregar. Bateria de 3.900 mAh O Moto Maxx tem bateria de 3.900mAh que não deixa parar Carregamento turbo Use o carregamento turbo por apenas 15 minutos para ter até 6 horas de uso.\r\n</p>');
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (8, 'GPD', 'SMARTPHONE SAMSUNG GALAXY GRAN PRIME DUOS', 'celular', '5 POLEGADAS', '500.00', '730.00', 0, 'SGGPDUOS.jpg', 4, 11, '', '', '', '', '', '', NULL, 1, 1, '');
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (6, 'MTG3', 'MOTO G 3° GERAÇAO', 'celular', '5 POLEGADAS', '700.00', '900.00', 0, 'no_image.jpg', 4, 2, '', '', '', '', '', '', 350, 1, 0, '<p>\r\n    O Motorola Moto G 16GB é um smartphone <strong>Android</strong> com características inovadoras em todos os pontos de vista que permite ser útil para qualquer forma de entretenimento, a qualquer hora e em qualquer lugar, representando um dos melhores dispositivos móveis já feitos. A tela de <strong>5</strong> polegadas é um verdadeiro record que coloca esse Motorola no topo de sua categoria. A resolução também é alta: <strong>1 80x720</strong> pixel  As funcionalidades oferecidas pelo Motorola Moto G 16GB são muitas e todas top de linha. Começando pelo<strong>LTE 4G</strong> que permite a transferência de dados e excelente navegação na internet, além de conectividade <strong>Wi-fi</strong>e <strong>GPS</strong> presente no aparelho<strong>.</strong>\r\n</p>');
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (7, 'LGP', 'SMARTPHONE LG Prime', 'celular', '5 POLEGADAS', '678.00', '898.00', 0, 'lgPrime.jpg', 4, 8, '', '', '', '', '', '', NULL, 1, 1, '');
INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (9, 'PH5S', 'IPHONE 5S', 'celular', '5,2 POLEGADAS', '900.00', '1.45', 0, 'iPhone_5S_1.jpg', 4, 14, '', '', '', '', '', '', 500, 1, 1, '');


#
# TABLE STRUCTURE FOR: purchase_items
#

DROP TABLE IF EXISTS purchase_items;

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `tax_amount` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(255) DEFAULT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (1, 1, 3, 'NTP', 'ULTRABOOK POSITIVO 14\" TB 32 GB', 1, '800.00', NULL, '800.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (2, 2, 1, 'SGT08', 'SAMSUNG GALAXY TAB 8\" 16 GB 3G WIFI', 30, '500.00', NULL, '15000.00', 2, '24.00%', '3600.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (3, 3, 3, 'NTP', 'ULTRABOOK POSITIVO 14\" TB 32 GB', 10, '800.00', NULL, '8000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (4, 4, 4, 'QB', 'QBEX Windows 10 Quad Core 8 GB 500 GB', 40, '800.00', NULL, '32000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (5, 5, 5, 'MMX', 'MOTO MAXX', 200, '600.00', NULL, '120000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (6, 6, 4, 'QB', 'QBEX Windows 10 Quad Core 8 GB 500 GB', 100, '800.00', NULL, '80000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (7, 7, 1, 'SGT08', 'SAMSUNG GALAXY TAB 8\" 16 GB 3G WIFI', 200, '500.00', NULL, '100000.00', 2, '24.00%', '24000.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (8, 7, 3, 'NTP', 'ULTRABOOK POSITIVO 14\" TB 32 GB', 300, '800.00', NULL, '240000.00', 2, '24.00%', '57600.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (9, 7, 5, 'MMX', 'MOTO MAXX', 100, '600.00', NULL, '60000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (10, 7, 6, 'MTG3', 'MOT G 3° GERAÇAO', 350, '700.00', NULL, '245000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (11, 8, 5, 'MMX', 'MOTO MAXX', 100, '600.00', NULL, '60000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (12, 8, 3, 'NTP', 'ULTRABOOK POSITIVO 14\" TB 32 GB', 200, '800.00', NULL, '160000.00', 1, '0.00', '0.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (13, 9, 1, 'SGT08', 'SAMSUNG GALAXY TAB 8\" 16 GB 3G WIFI', 300, '500.00', NULL, '150000.00', 2, '24.00%', '36000.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `tax_rate_id`, `tax`, `val_tax`) VALUES (14, 10, 9, 'PH5S', 'IPHONE 5S', 500, '900.00', NULL, '450000.00', 1, '0.00', '0.00');


#
# TABLE STRUCTURE FOR: purchases
#

DROP TABLE IF EXISTS purchases;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  `inv_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (1, 'PO-0003', 2, 4, 'POSITIVO', '2016-04-29', '', '800.00', 'Pedro Henrique Santanna', NULL, '0.00', '800.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (2, 'PO-0002', 3, 3, 'SAMSUNG', '2016-04-29', '', '18600.00', 'Pedro Henrique Santanna', NULL, '3600.00', '15000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (3, 'PO-0003', 3, 4, 'POSITIVO', '2016-04-29', '', '8000.00', 'Pedro Henrique Santanna', NULL, '0.00', '8000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (4, 'PO-0004', 2, 5, 'INTEL LTDA', '2016-04-30', '', '32000.00', 'Pedro Henrique Santanna', NULL, '0.00', '32000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (5, 'PO-0005', 3, 6, 'MOTOROLLA', '2016-04-30', '', '120000.00', 'Pedro Henrique Santanna', NULL, '0.00', '120000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (6, 'PO-0006', 4, 5, 'INTEL LTDA', '2016-04-30', '', '80000.00', 'Pedro Henrique Santanna', NULL, '0.00', '80000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (7, 'PO-0007', 4, 6, 'MOTOROLLA', '2016-05-01', '', '726600.00', 'Karolyne Correia Vieira', NULL, '81600.00', '645000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (8, 'PO-0008', 2, 4, 'POSITIVO', '2016-05-02', '', '220000.00', 'Pedro Henrique Santanna', NULL, '0.00', '220000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (9, 'PO-0009', 2, 3, 'SAMSUNG', '2016-05-31', '', '186000.00', 'Pedro Henrique Santanna', NULL, '36000.00', '150000.00');
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`, `total_tax`, `inv_total`) VALUES (10, 'PO-0010', 2, 7, 'Apple', '2016-06-21', '', '450000.00', 'Pedro Henrique Santanna', NULL, '0.00', '450000.00');


#
# TABLE STRUCTURE FOR: quote_items
#

DROP TABLE IF EXISTS quote_items;

CREATE TABLE `quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quote_id` (`quote_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO quote_items (`id`, `quote_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount_id`, `discount`) VALUES (1, 1, 1, 'SGT08', 'SAMSUNG GALAXY TAB 8\" 16 GB 3G WIFI', 'TABLET', 1, '0.00', 2, '900.00', '1800.00', '0.00', NULL, '0.00', 1, '0.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount_id`, `discount`) VALUES (2, 1, 6, 'MTG3', 'MOT G 3° GERAÇAO', 'celular', 1, '0.00', 1, '900.00', '900.00', '0.00', NULL, '0.00', 1, '0.00');


#
# TABLE STRUCTURE FOR: quotes
#

DROP TABLE IF EXISTS quotes;

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO quotes (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `user`, `updated_by`, `inv_discount`, `discount_id`, `shipping`) VALUES (1, 'QU-0001', 4, 5, 'Jefferson Aurore', 3, 'Leonardo Ferro', '2016-05-01', '', '', '2700.00', '0.00', '2700.00', NULL, NULL, '0.00', 1, 'Leonardo Ferro', NULL, '0.00', 0, '0.00');


#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (13, 6, 3, 'NTP', 'ULTRABOOK POSITIVO 14\" TB 32 GB', 'NOTEBOOKS', 2, '24.00%', 1, '1600.00', '1600.00', '384.00', '', '0.00', '0.00', 1);


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `paid_by` varchar(55) DEFAULT 'cash',
  `count` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  `pos` tinyint(4) NOT NULL DEFAULT '0',
  `paid` decimal(25,2) DEFAULT NULL,
  `cc_no` varchar(20) DEFAULT NULL,
  `cc_holder` varchar(100) DEFAULT NULL,
  `cheque_no` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (6, 'SL-0006', 3, 2, 'Pedro Henrique', 5, 'Karolyne Correia', '2016-05-01', NULL, NULL, '1600.00', '384.00', '1984.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Pedro Henrique Santanna', NULL, 'cash', 1, '0.00', 1, '1984.00', '', '', '');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `setting_id` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo2` varchar(255) NOT NULL,
  `site_name` varchar(55) NOT NULL,
  `language` varchar(20) NOT NULL,
  `default_warehouse` int(2) NOT NULL,
  `currency_prefix` varchar(3) NOT NULL,
  `default_invoice_type` int(2) NOT NULL,
  `default_tax_rate` int(2) NOT NULL,
  `rows_per_page` int(2) NOT NULL,
  `no_of_rows` int(2) NOT NULL,
  `total_rows` int(2) NOT NULL,
  `version` varchar(5) NOT NULL DEFAULT '2.3',
  `default_tax_rate2` int(11) NOT NULL DEFAULT '0',
  `dateformat` int(11) NOT NULL,
  `sales_prefix` varchar(20) NOT NULL,
  `quote_prefix` varchar(55) NOT NULL,
  `purchase_prefix` varchar(55) NOT NULL,
  `transfer_prefix` varchar(55) NOT NULL,
  `barcode_symbology` varchar(20) NOT NULL,
  `theme` varchar(20) NOT NULL,
  `product_serial` tinyint(4) NOT NULL,
  `default_discount` int(11) NOT NULL,
  `discount_option` tinyint(4) NOT NULL,
  `discount_method` tinyint(4) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL,
  `restrict_sale` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_user` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_calendar` tinyint(4) NOT NULL DEFAULT '0',
  `bstatesave` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`setting_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO settings (`setting_id`, `logo`, `logo2`, `site_name`, `language`, `default_warehouse`, `currency_prefix`, `default_invoice_type`, `default_tax_rate`, `rows_per_page`, `no_of_rows`, `total_rows`, `version`, `default_tax_rate2`, `dateformat`, `sales_prefix`, `quote_prefix`, `purchase_prefix`, `transfer_prefix`, `barcode_symbology`, `theme`, `product_serial`, `default_discount`, `discount_option`, `discount_method`, `tax1`, `tax2`, `restrict_sale`, `restrict_user`, `restrict_calendar`, `bstatesave`) VALUES (1, 'HomePackPequeno.png', 'LogoHomePackSmall.png', 'HomePack', 'bportuguese', 2, 'R$', 2, 0, 10, 9, 30, '2.3', 0, 5, 'SL', 'QU', 'PO', 'TR', 'ean13', 'blue', 1, 1, 2, 2, 0, 0, 0, 0, 0, 1);


#
# TABLE STRUCTURE FOR: subcategories
#

DROP TABLE IF EXISTS subcategories;

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (1, 2, 'CD', 'DELL');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (2, 4, 'SMT', 'MOTOROLLA');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (3, 3, 'TBLG', 'LG ');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (4, 2, 'AL', 'ALL IN ONE');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (9, 3, 'TBM', 'MOTOROLLA XOOM');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (5, 2, 'NT', 'NOTEBOOK');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (6, 3, 'TBS', 'SAMSUNG');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (7, 4, 'XOM', 'XIAOMI');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (8, 4, 'LGK', 'LG ');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (10, 3, 'TBMS', 'MULTILASER');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (11, 4, 'SSG', 'SAMSUNG');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (12, 2, 'AI1', 'all in one');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (13, 3, 'GNS', 'genesis');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (14, 4, 'APPL', 'iphones');
INSERT INTO subcategories (`id`, `category_id`, `code`, `name`) VALUES (15, 3, 'IPD', 'IPAD 7');


#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS suppliers;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (2, 'DELL', 'DELL', 'RUA DA ALFANDEGA', 'RIO DE JANEIRO', 'RJ', '28990000', 'Brasil', '2193456789', 'support@dell.com', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (3, 'SAMSUNG', 'SAMSUNG', 'AV.RIO BRANCO', 'RIO DE JANEIRO', 'RJ', '28990000', 'BRASIL', '2198994563', 'support@samsung.com', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (4, 'POSITIVO', 'POSITIVO LTDA', 'AV. PRESIDENTE VARGAS 174', 'RIO DE JANEIRO', 'RJ', '28990000', 'Brasil', '2298993874', 'suporte@negativo.com.br', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (5, 'INTEL LTDA', 'INTEL INSIDE', 'Rua do Delírio', 'Algum lugar do Brasil', 'São Paulo', '23411045', 'Brasil', '21934567891', 'support@intel.com', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (6, 'MOTOROLLA', 'LENOVO GROUP LTDA', 'Av.Morrinson 56', 'Morrisville', 'Carolina do Norte', '8739019', 'EUA', '345673984', 'supportlenovo@lenovo.com', '', '', '', '', '', '');
INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (7, 'Apple', 'Apple', 'Rua José Clemente', 'Niterói', 'RJ', '24130350', 'Brasil', '2134567684', 'support@apple.com', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: suspended_bills
#

DROP TABLE IF EXISTS suspended_bills;

CREATE TABLE `suspended_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `tax1` float(25,2) DEFAULT NULL,
  `tax2` float(25,2) DEFAULT NULL,
  `discount` decimal(25,2) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total` float(25,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: suspended_items
#

DROP TABLE IF EXISTS suspended_items;

CREATE TABLE `suspended_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suspend_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) DEFAULT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tax_rates
#

DROP TABLE IF EXISTS tax_rates;

CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `rate` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (1, 'No Tax', '0.00', '2');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (2, 'VAT', '24.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (3, 'GST', '6.00', '1');


#
# TABLE STRUCTURE FOR: transfer_items
#

DROP TABLE IF EXISTS transfer_items;

CREATE TABLE `transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `tax_val` decimal(25,2) DEFAULT NULL,
  `unit_price` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO transfer_items (`id`, `transfer_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `quantity`, `tax_rate_id`, `tax`, `tax_val`, `unit_price`, `gross_total`) VALUES (1, 1, 1, 'SGT08', 'SAMSUNG GALAXY TAB 8\" 16 GB 3G WIFI', 'TABLET', 200, 2, '24.00%', '24000.00', '500.00', '100000.00');
INSERT INTO transfer_items (`id`, `transfer_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `quantity`, `tax_rate_id`, `tax`, `tax_val`, `unit_price`, `gross_total`) VALUES (2, 2, 3, 'NTP', 'ULTRABOOK POSITIVO 14\" TB 32 GB', 'NOTEBOOKS', 10, 1, '0.00', '0.00', '800.00', '8000.00');
INSERT INTO transfer_items (`id`, `transfer_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `quantity`, `tax_rate_id`, `tax`, `tax_val`, `unit_price`, `gross_total`) VALUES (3, 3, 9, 'PH5S', 'IPHONE 5S', 'celular', 300, 1, '0.00', '0.00', '900.00', '270000.00');


#
# TABLE STRUCTURE FOR: transfers
#

DROP TABLE IF EXISTS transfers;

CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `from_warehouse_code` varchar(55) NOT NULL,
  `from_warehouse_name` varchar(55) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `to_warehouse_code` varchar(55) NOT NULL,
  `to_warehouse_name` varchar(55) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) DEFAULT NULL,
  `tr_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO transfers (`id`, `transfer_no`, `date`, `from_warehouse_id`, `from_warehouse_code`, `from_warehouse_name`, `to_warehouse_id`, `to_warehouse_code`, `to_warehouse_name`, `note`, `user`, `total_tax`, `total`, `tr_total`) VALUES (1, 'TR-0001', '2016-04-10', 3, 'HP02', 'HomePack - Niterói', 2, 'HP01', 'HomePack - Saquarema', '', 'Pedro Henrique Santanna', '24000.00', '124000.00', '100000.00');
INSERT INTO transfers (`id`, `transfer_no`, `date`, `from_warehouse_id`, `from_warehouse_code`, `from_warehouse_name`, `to_warehouse_id`, `to_warehouse_code`, `to_warehouse_name`, `note`, `user`, `total_tax`, `total`, `tr_total`) VALUES (2, 'TR-0002', '2016-04-30', 3, 'HP02', 'HomePack - Niterói', 2, 'HP01', 'HomePack - Saquarema', '', 'Pedro Henrique Santanna', '0.00', '8000.00', '8000.00');
INSERT INTO transfers (`id`, `transfer_no`, `date`, `from_warehouse_id`, `from_warehouse_code`, `from_warehouse_name`, `to_warehouse_id`, `to_warehouse_code`, `to_warehouse_name`, `note`, `user`, `total_tax`, `total`, `tr_total`) VALUES (3, 'TR-0003', '2016-06-21', 2, 'HP01', 'HomePack - (Central) Saquarema', 4, 'HP03', 'HomePack - Barra da Tijuca', '', 'Pedro Henrique Santanna', '0.00', '270000.00', '270000.00');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (3, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'karolyne correia vieira', '20c5742145686a735743e1c0ca1bfaaa29c139f6', NULL, 'karolyne.correa@homepack.com.br', NULL, NULL, NULL, NULL, 1460335831, 1465880317, 1, 'Karolyne Correia', 'Vieira', 'HomePack', '2198765432');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (2, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'pedro henrique santanna', 'c6b9710962d1d4ce7bc39971d7e8ef8bfb8f8427', NULL, 'pedrohesm@homepack.com.br', NULL, NULL, NULL, NULL, 1460223819, 1466689724, 1, 'Pedro Henrique', 'Santanna', 'HomePack', '21969631823');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (4, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'leonardo ferro', '49c23e8f56f1ed4d65da3738919daadbc4d450dd', NULL, 'leonardo@homepack.com.br', NULL, NULL, NULL, NULL, 1462024175, 1465514760, 1, 'Leonardo', 'Ferro', 'LF Consultoria', '2198765431');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (5, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'jefferson aurore', '68b2b43ecd629d38a8caec02a62843ee1eb9b2a0', NULL, 'jeff@homepack.com.br', NULL, NULL, NULL, NULL, 1462024210, 1465514690, 1, 'Jefferson', 'Aurore', 'Stand UP Comedy', '2122240660');


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS users_groups;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (3, 3, 1);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (2, 2, 1);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (4, 4, 1);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (5, 5, 1);


#
# TABLE STRUCTURE FOR: warehouses
#

DROP TABLE IF EXISTS warehouses;

CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (3, 'HP02', 'HomePack - Niterói', 'Rua Engenheiro Péricles Ribeiro - Fonseca', 'Niterói');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (2, 'HP01', 'HomePack - (Central) Saquarema', 'Rua 96.', 'Saquarema');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (4, 'HP03', 'HomePack - Barra da Tijuca', 'Av. das Américas 11', 'Rio de Janeiro');


#
# TABLE STRUCTURE FOR: warehouses_products
#

DROP TABLE IF EXISTS warehouses_products;

CREATE TABLE `warehouses_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (6, 3, 2, 211);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (5, 4, 2, 40);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (3, 1, 3, -170);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (4, 1, 2, 500);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (7, 3, 3, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (8, 5, 2, 100);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (9, 4, 3, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (10, 5, 3, 200);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (11, 4, 4, 100);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (12, 1, 4, 200);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (13, 6, 4, 350);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (14, 6, 2, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (15, 6, 3, 0);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (16, 3, 4, 300);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (17, 5, 4, 100);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (18, 9, 2, 200);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (19, 9, 4, 300);


